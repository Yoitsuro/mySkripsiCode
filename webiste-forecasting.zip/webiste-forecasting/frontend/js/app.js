const API_BASE = "http://localhost:8000";

let priceChart = null;

document.addEventListener("DOMContentLoaded", () => {
  setupNavigation();
  setupHomePage();
  setupMetricsPage();
  setupForecastPage();

  // initial load
  loadHistory(1);
  loadMetrics();
});

function setupNavigation() {
  const navButtons = document.querySelectorAll(".nav-btn");
  const pages = document.querySelectorAll(".page");

  navButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.page;

      navButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      pages.forEach((p) => {
        if (p.id === `page-${target}`) {
          p.classList.add("active");
        } else {
          p.classList.remove("active");
        }
      });
    });
  });
}

/* ========== HOME PAGE ========== */

function setupHomePage() {
  const rangeButtons = document.querySelectorAll(".range-btn");
  rangeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      rangeButtons.forEach((b) => b.classList.remove("primary"));
      btn.classList.add("primary");
      const days = parseInt(btn.dataset.days, 10);
      loadHistory(days);
    });
  });
}

async function loadHistory(days) {
  const statusEl = document.getElementById("homeStatus");
  statusEl.textContent = "Mengambil data harga...";
  if (priceChart) {
    priceChart.destroy();
  }

  try {
    const res = await fetch(`${API_BASE}/history?symbol=ETH/USDT&days=${days}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const series = data.data || [];

    const labels = series.map((d) => d.timestamp);
    const prices = series.map((d) => d.close);

    const ctx = document.getElementById("priceChart").getContext("2d");
    priceChart = new Chart(ctx, {
      type: "line",
      data: {
        labels,
        datasets: [
          {
            label: `Close Price (${data.timeframe})`,
            data: prices,
            fill: false,
            borderWidth: 1,
            pointRadius: 0,
          },
        ],
      },
      options: {
        responsive: true,
        scales: {
          x: {
            ticks: {
              maxTicksLimit: 12,
            },
          },
          y: {
            beginAtZero: false,
          },
        },
      },
    });

    statusEl.textContent = `Menampilkan ${data.symbol} untuk ${data.days} hari terakhir (interval ${data.timeframe}).`;
  } catch (err) {
    console.error(err);
    statusEl.textContent =
      "Gagal mengambil data harga (cek backend & koneksi).";
  }
}

/* ========== METRICS PAGE ========== */

function setupMetricsPage() {
  // kalau nanti mau tombol refresh, bisa di-setup di sini
}

async function loadMetrics() {
  const statusEl = document.getElementById("metricsStatus");
  const tbody = document.querySelector("#metricsTable tbody");
  statusEl.textContent = "Mengambil metrics...";
  tbody.innerHTML = "";

  try {
    const res = await fetch(`${API_BASE}/metrics`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    Object.entries(data).forEach(([modelName, metrics]) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${modelName}</td>
        <td>${metrics.RMSE !== undefined ? metrics.RMSE.toFixed(4) : "-"}</td>
        <td>${metrics.MSE !== undefined ? metrics.MSE.toFixed(4) : "-"}</td>
        <td>${metrics.MAE !== undefined ? metrics.MAE.toFixed(4) : "-"}</td>
        <td>${metrics.MAPE !== undefined ? metrics.MAPE.toFixed(4) : "-"}</td>
      `;
      tbody.appendChild(tr);
    });

    statusEl.textContent = "Metrics berhasil dimuat.";
  } catch (err) {
    console.error(err);
    statusEl.textContent =
      "Gagal mengambil metrics (cek backend & file metrics_eth.csv).";
  }
}

/* ========== FORECAST PAGE ========== */

function setupForecastPage() {
  const btnForecast = document.getElementById("btnForecast");
  btnForecast.addEventListener("click", doForecast);
}

async function doForecast() {
  const statusEl = document.getElementById("forecastStatus");
  const tbody = document.querySelector("#forecastTable tbody");
  const presetCheckboxes = document.querySelectorAll(".preset-horizon");
  const customInput = document.getElementById("customHorizon");

  statusEl.textContent = "";
  tbody.innerHTML = "";

  // Kumpulkan horizons
  const horizons = new Set();
  presetCheckboxes.forEach((cb) => {
    if (cb.checked) horizons.add(parseInt(cb.value, 10));
  });

  const customVal = customInput.value.trim();
  if (customVal) {
    const n = parseInt(customVal, 10);
    if (isNaN(n) || n < 1 || n > 168) {
      statusEl.textContent = "Custom horizon harus antara 1 hingga 168 jam.";
      return;
    }
    horizons.add(n);
  }

  if (horizons.size === 0) {
    statusEl.textContent = "Pilih minimal satu horizon.";
    return;
  }

  const hoursArr = Array.from(horizons).sort((a, b) => a - b);
  const horizonsStr = hoursArr.join(",");

  statusEl.textContent = "Menghitung forecast...";

  try {
    const url = `${API_BASE}/forecast?symbol=${encodeURIComponent(
      "ETH/USDT"
    )}&horizons=${encodeURIComponent(horizonsStr)}`;
    const res = await fetch(url);
    if (!res.ok) {
      const msg = await res.text();
      throw new Error(`HTTP ${res.status}: ${msg}`);
    }
    const data = await res.json();

    const entries = Object.entries(data.results || {});
    entries.sort((a, b) => {
      const ha = parseInt(a[0].replace("h", ""), 10);
      const hb = parseInt(b[0].replace("h", ""), 10);
      return ha - hb;
    });

    entries.forEach(([key, info]) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${key}</td>
        <td>${info.steps_used}</td>
        <td>${Number(info.pred_stack).toFixed(4)}</td>
      `;
      tbody.appendChild(tr);
    });

    statusEl.textContent = `Forecast selesai. Timeframe: ${data.timeframe}.`;
  } catch (err) {
    console.error(err);
    statusEl.textContent =
      "Terjadi error saat memanggil API forecast. Cek log backend.";
  }
}
