from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd

from forecasting_core import CONFIG, fetch_ohlcv_ccxt, forecast_hours
from model_loader import load_models

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # untuk development, boleh semua origin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Load model sekali di awal
model_lgb, model_tcn, meta_model = load_models()

# Coba load metrics; kalau tidak ada, pakai DataFrame kosong
try:
    metrics_df = pd.read_csv("metrics_eth.csv", index_col=0)
except FileNotFoundError:
    metrics_df = pd.DataFrame()


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/metrics")
def get_metrics():
    if metrics_df.empty:
        # Supaya jelas kalau file metrics belum ada
        raise HTTPException(status_code=500, detail="metrics_eth.csv tidak ditemukan atau kosong.")
    return metrics_df.to_dict(orient="index")


@app.get("/forecast")
def get_forecast(
    symbol: str = "ETH/USDT",
    horizons: str = "1,10,24,48,72",
):
    # 1) Parse horizons
    try:
        hours_list = [int(h.strip()) for h in horizons.split(",") if h.strip()]
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail="Format horizons tidak valid. Contoh: 1,10,24,48,72"
        )

    # 2) Ambil data OHLCV terbaru
    try:
        df = fetch_ohlcv_ccxt(
            symbol=symbol,
            timeframe=CONFIG.timeframe,
            limit=500,  # cukup untuk seq_len=168 + buffer
        )
    except Exception as e:
        print("Error saat fetch_ohlcv_ccxt:", repr(e))
        raise HTTPException(status_code=500, detail=f"Gagal mengambil data OHLCV: {e}")

    # 3) Pastikan panjang data cukup
    if len(df) < CONFIG.seq_len + 5:
        raise HTTPException(
            status_code=500,
            detail=f"Data OHLCV terlalu sedikit ({len(df)} baris). Butuh minimal {CONFIG.seq_len + 5} baris."
        )

    # 4) Hitung forecast
    try:
        results = forecast_hours(
            df_input=df,
            hours_list=hours_list,
            seq_len=CONFIG.seq_len,
            model_lgb=model_lgb,
            model_tcn=model_tcn,
            meta_model=meta_model,
        )
    except Exception as e:
        print("Error saat forecast_hours:", repr(e))
        raise HTTPException(status_code=500, detail=f"Terjadi error saat menghitung forecast: {e}")

    return {
        "symbol": symbol,
        "timeframe": CONFIG.timeframe,
        "results": results,
    }
